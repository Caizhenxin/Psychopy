This is a simple repo for Mental Health Education Center's project.
including IAT and some inventories.